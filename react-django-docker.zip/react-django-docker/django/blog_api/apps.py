from django.apps import AppConfig


class BlogApiConfig(AppConfig):
    name = 'blog_api'
